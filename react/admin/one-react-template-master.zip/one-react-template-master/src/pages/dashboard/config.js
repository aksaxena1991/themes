export default {
    app: {
        colors: {
            primary: "#005792",
            secondary: "#798892",
            success: "#81D4BB",
            info: "#4DC7DF",
            warning: "#FFBF69",
            danger: "#FF7769",
            inverse: "#002B49",
            textColor: "#495057",
            gray: "#D7DFE6"
        },
    }
};
