# Changelog

## [1.0.1]

### Fixed

- Remove unnecessary packages, actions, reducers
- Rename token to authenticated 

## [1.0.0]

Release Flatlogic One React Template
