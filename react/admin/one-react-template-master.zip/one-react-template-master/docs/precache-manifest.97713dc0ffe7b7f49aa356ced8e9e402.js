self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "193a8e8af8ae66ebe4ce1bbfd5d603b9",
    "url": "./index.html"
  },
  {
    "revision": "67974a9143f2762397b7",
    "url": "./tables/css/2.134a3e29.chunk.css"
  },
  {
    "revision": "c22aa9ce860534c40b6c",
    "url": "./tables/css/main.d459b525.chunk.css"
  },
  {
    "revision": "67974a9143f2762397b7",
    "url": "./tables/js/2.67974a91.chunk.js"
  },
  {
    "revision": "c22aa9ce860534c40b6c",
    "url": "./tables/js/main.c22aa9ce.chunk.js"
  },
  {
    "revision": "2a54d9e93026e45eee9d",
    "url": "./tables/js/runtime~main.2a54d9e9.js"
  },
  {
    "revision": "610f2a5ad8f48b6865b65aa96ecf2096",
    "url": "./tables/media/1.png"
  },
  {
    "revision": "cd708aaac1c953ebc42aa3b58f13d921",
    "url": "./tables/media/2.png"
  },
  {
    "revision": "e2e9acc3d90c79b5903b9835c09e5638",
    "url": "./tables/media/3.png"
  },
  {
    "revision": "991dc9b0b62193a74474aa78ed9d7236",
    "url": "./tables/media/4.png"
  },
  {
    "revision": "0406308c7c726a1b1c779130462ea42d",
    "url": "./tables/media/5.png"
  },
  {
    "revision": "c8bdf8be28953f2f63c59a9d2c9377a1",
    "url": "./tables/media/Charts_filled.c8bdf8be.svg"
  },
  {
    "revision": "883aa3ecb5733bf12d7a14cf98048fa3",
    "url": "./tables/media/Charts_outlined.883aa3ec.svg"
  },
  {
    "revision": "c2473ccc32feb9f515cbd4cb0b22d960",
    "url": "./tables/media/Core_filled.c2473ccc.svg"
  },
  {
    "revision": "a52ba5ada197237f1d2482b65036db15",
    "url": "./tables/media/Core_outlined.a52ba5ad.svg"
  },
  {
    "revision": "d8f5221806c351e91cbd07e7d35142f8",
    "url": "./tables/media/Documentation_filled.d8f52218.svg"
  },
  {
    "revision": "f94839972af51f0de1f63e56e7f73d84",
    "url": "./tables/media/Documentation_outlined.f9483997.svg"
  },
  {
    "revision": "0b38a3a95413b9f7191db414621d57b8",
    "url": "./tables/media/E-commerce_filled.0b38a3a9.svg"
  },
  {
    "revision": "d15cf9e318206489cb2fb2fe259c5158",
    "url": "./tables/media/E-commerce_outlined.d15cf9e3.svg"
  },
  {
    "revision": "84c20c1d24d1d23aea678ed60fbb8612",
    "url": "./tables/media/Email_filled.84c20c1d.svg"
  },
  {
    "revision": "339db59ac5445b14c07b417f63db898b",
    "url": "./tables/media/Email_outlined.339db59a.svg"
  },
  {
    "revision": "0c6755dd995fe96a629533b75b4475a8",
    "url": "./tables/media/Flaticon.0c6755dd.svg"
  },
  {
    "revision": "76ed06ab10a4112fa3bb33bbf320cb6d",
    "url": "./tables/media/Flaticon.76ed06ab.woff"
  },
  {
    "revision": "90bc8831ccc880209459e741dc3ad6e2",
    "url": "./tables/media/Flaticon.90bc8831.ttf"
  },
  {
    "revision": "96850e104a54cdeb774cf1185b088d14",
    "url": "./tables/media/Flaticon.96850e10.eot"
  },
  {
    "revision": "dd194edcf14d1c2ba6fc720b3b712691",
    "url": "./tables/media/Forms_filled.dd194edc.svg"
  },
  {
    "revision": "3c7fcbb823a38f867416196b09286792",
    "url": "./tables/media/Forms_outlined.3c7fcbb8.svg"
  },
  {
    "revision": "bd3025cb571dfe0f262cf15758651222",
    "url": "./tables/media/Grid_filled.bd3025cb.svg"
  },
  {
    "revision": "9a053915d2a144040d4b74405f41a06c",
    "url": "./tables/media/Grid_outlined.9a053915.svg"
  },
  {
    "revision": "946c09e21424902c295b17269719df91",
    "url": "./tables/media/Logout_filled.946c09e2.svg"
  },
  {
    "revision": "4856905089137aa8345bacc49d3a1e17",
    "url": "./tables/media/Logout_outlined.48569050.svg"
  },
  {
    "revision": "85c0a89d94240d7b40cd485d795ed2a4",
    "url": "./tables/media/Maps_filled.85c0a89d.svg"
  },
  {
    "revision": "a72cf3950c5bca9d66e6c1fadfa6e834",
    "url": "./tables/media/Maps_outlined.a72cf395.svg"
  },
  {
    "revision": "bcda2ae6a34eb5adfb1cb8b7a8ecc176",
    "url": "./tables/media/Package_filled.bcda2ae6.svg"
  },
  {
    "revision": "a27e25b6480ab6828365aeaa5b8e1012",
    "url": "./tables/media/Package_outlined.a27e25b6.svg"
  },
  {
    "revision": "6e13f8c5c0d75479df9458e057d9b770",
    "url": "./tables/media/Profile_filled.6e13f8c5.svg"
  },
  {
    "revision": "e3aaf1c72f2ea7c42d515fbbda867cf7",
    "url": "./tables/media/Profile_outlined.e3aaf1c7.svg"
  },
  {
    "revision": "59f836baab4cd7f7b41008e4ee414f6b",
    "url": "./tables/media/Settings_filled.59f836ba.svg"
  },
  {
    "revision": "430649b1127c16227aea1266d1f285df",
    "url": "./tables/media/Settings_outlined.430649b1.svg"
  },
  {
    "revision": "ddffa99f297b19baf6ff1d7b74a7f992",
    "url": "./tables/media/Tables_filled.ddffa99f.svg"
  },
  {
    "revision": "7ea18898033ed6d16e3685720a4a473c",
    "url": "./tables/media/Tables_outlined.7ea18898.svg"
  },
  {
    "revision": "c79df574eea996c6b67dd60c6298bc06",
    "url": "./tables/media/Typography-dark.c79df574.svg"
  },
  {
    "revision": "1e823918a9ae0cc9b00c4659479e4f2d",
    "url": "./tables/media/Typography.1e823918.svg"
  },
  {
    "revision": "c79df574eea996c6b67dd60c6298bc06",
    "url": "./tables/media/Typography_filled.c79df574.svg"
  },
  {
    "revision": "1e823918a9ae0cc9b00c4659479e4f2d",
    "url": "./tables/media/Typography_outlined.1e823918.svg"
  },
  {
    "revision": "588c0a39cf0497873f855c72471aa077",
    "url": "./tables/media/Vector-1.588c0a39.svg"
  },
  {
    "revision": "e49f02f38f9a4cac0382cbfbd7463057",
    "url": "./tables/media/Vector-2.e49f02f3.svg"
  },
  {
    "revision": "1fd70f225a5b08e99d7e7846c018087e",
    "url": "./tables/media/Vector-3.1fd70f22.svg"
  },
  {
    "revision": "ec4a6468fabcd2862053efaa50e96031",
    "url": "./tables/media/Vector-4.ec4a6468.svg"
  },
  {
    "revision": "f6dc73f25f30df2d36d0ae1d57f4c1fa",
    "url": "./tables/media/a3.jpg"
  },
  {
    "revision": "84f014f09e2520f76be61769a1bb6440",
    "url": "./tables/media/a5.jpg"
  },
  {
    "revision": "2966ab8e577f1e16f7cdb100af95f5a5",
    "url": "./tables/media/a6.jpg"
  },
  {
    "revision": "83542cf8870cc6652503a5be45bae35d",
    "url": "./tables/media/account.83542cf8.svg"
  },
  {
    "revision": "f092be1191dfba3275fb9ecabf53e348",
    "url": "./tables/media/arrow-right.f092be11.svg"
  },
  {
    "revision": "3ca0b1e1449fe2b0c8971989ac90f3f5",
    "url": "./tables/media/caret-active.3ca0b1e1.svg"
  },
  {
    "revision": "733b447691fa04a3b291c09e606ff981",
    "url": "./tables/media/caret.733b4476.svg"
  },
  {
    "revision": "acb11e5d18d585f54a33f72ee7c22606",
    "url": "./tables/media/dark-dashboard.acb11e5d.svg"
  },
  {
    "revision": "ba6ab3b26861b6bad1ded79bc0a9a5fb",
    "url": "./tables/media/error-page-img.ba6ab3b2.svg"
  },
  {
    "revision": "674f50d287a8c48dc19ba404d20fe713",
    "url": "./tables/media/fontawesome-webfont.674f50d2.eot"
  },
  {
    "revision": "912ec66d7572ff821749319396470bde",
    "url": "./tables/media/fontawesome-webfont.912ec66d.svg"
  },
  {
    "revision": "af7ae505a9eed503f8b8e6982036873e",
    "url": "./tables/media/fontawesome-webfont.af7ae505.woff2"
  },
  {
    "revision": "b06871f281fee6b241d60582ae9369b9",
    "url": "./tables/media/fontawesome-webfont.b06871f2.ttf"
  },
  {
    "revision": "fee66e712a8a08eef5805a46892932ad",
    "url": "./tables/media/fontawesome-webfont.fee66e71.woff"
  },
  {
    "revision": "448c34a56d699c29117adc64c43affeb",
    "url": "./tables/media/glyphicons-halflings-regular.448c34a5.woff2"
  },
  {
    "revision": "89889688147bd7575d6327160d64e760",
    "url": "./tables/media/glyphicons-halflings-regular.89889688.svg"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "./tables/media/glyphicons-halflings-regular.d41d8cd9.ttf"
  },
  {
    "revision": "f4769f9bdb7466be65088239c12046d1",
    "url": "./tables/media/glyphicons-halflings-regular.f4769f9b.eot"
  },
  {
    "revision": "fa2772327f55d8198301fdb8bcfc8158",
    "url": "./tables/media/glyphicons-halflings-regular.fa277232.woff"
  },
  {
    "revision": "88f555d57e10aeb7e41a6f86d40485d5",
    "url": "./tables/media/light-dashboard.88f555d5.svg"
  },
  {
    "revision": "2467abe4ea11bd3c32ed6cf054cc7120",
    "url": "./tables/media/light-notify.2467abe4.svg"
  },
  {
    "revision": "131b7f1e91a652791f08f5ccfe702645",
    "url": "./tables/media/line-awesome.131b7f1e.svg"
  },
  {
    "revision": "3f85d8035b4ccd91d2a1808dd22b7684",
    "url": "./tables/media/line-awesome.3f85d803.eot"
  },
  {
    "revision": "452a5b42cb4819f09d35bcf6cbdb24c1",
    "url": "./tables/media/line-awesome.452a5b42.woff2"
  },
  {
    "revision": "4d42f5f0c62a8f51e876c14575354a6e",
    "url": "./tables/media/line-awesome.4d42f5f0.ttf"
  },
  {
    "revision": "8b1290595e57e1d49d95ff3fa1129ecc",
    "url": "./tables/media/line-awesome.8b129059.woff"
  },
  {
    "revision": "f063ba55cc56154e21d736999066b333",
    "url": "./tables/media/logo.f063ba55.svg"
  },
  {
    "revision": "575f587efe68caffa64fd442d88c2f80",
    "url": "./tables/media/logout.575f587e.svg"
  },
  {
    "revision": "043357f7c8e47fc6ccdc67ae9eaf3790",
    "url": "./tables/media/messages-filled.043357f7.svg"
  },
  {
    "revision": "6ba57c4d0a8f39a09eb09462e9ca8ef0",
    "url": "./tables/media/messages.6ba57c4d.svg"
  },
  {
    "revision": "693453197b1716b0163783e161757775",
    "url": "./tables/media/notify.69345319.svg"
  },
  {
    "revision": "ceb4c09cf44b0d649bae0ab5abb55aa7",
    "url": "./tables/media/orders.ceb4c09c.svg"
  },
  {
    "revision": "d6ebfe36f7ae942c1431c016268cdd8c",
    "url": "./tables/media/search.d6ebfe36.svg"
  },
  {
    "revision": "3b1fba2d7ba5bdc465505a7e86a851a9",
    "url": "./tables/media/settings.3b1fba2d.svg"
  },
  {
    "revision": "1d67a408ddc51ce562c9271448743c30",
    "url": "./tables/media/signinImg.1d67a408.svg"
  },
  {
    "revision": "86119dcfae1669b7dfe9c658f35c5c73",
    "url": "./tables/media/signupImg.86119dcf.svg"
  },
  {
    "revision": "013ee8fb311ffd63bcd50efd379af24a",
    "url": "./tables/media/smileImg.013ee8fb.svg"
  },
  {
    "revision": "bd347da150c7a29bb65a46f984d17e95",
    "url": "./tables/media/stocks.bd347da1.svg"
  },
  {
    "revision": "0fb6db630cbb62e3e8f83db33a7aeaf6",
    "url": "./tables/media/stocksDown.0fb6db63.svg"
  },
  {
    "revision": "ddffa99f297b19baf6ff1d7b74a7f992",
    "url": "./tables/media/tables-dark.ddffa99f.svg"
  },
  {
    "revision": "7ea18898033ed6d16e3685720a4a473c",
    "url": "./tables/media/tables.7ea18898.svg"
  },
  {
    "revision": "1983cf5b9c2eb01a16f4d88710d0197d",
    "url": "./tables/media/total-sale.1983cf5b.svg"
  },
  {
    "revision": "2f6cc17b73a02ea02b5d0585de2caca9",
    "url": "./tables/media/ui elements_filled.2f6cc17b.svg"
  },
  {
    "revision": "300b3ba5078cabfcc411c48585a962cb",
    "url": "./tables/media/ui elements_outlined.300b3ba5.svg"
  },
  {
    "revision": "2f6cc17b73a02ea02b5d0585de2caca9",
    "url": "./tables/media/ui-elements-dark.2f6cc17b.svg"
  },
  {
    "revision": "300b3ba5078cabfcc411c48585a962cb",
    "url": "./tables/media/ui-elements.300b3ba5.svg"
  },
  {
    "revision": "45bb36d41de69ffcbd4fb78ddd70c05b",
    "url": "./tables/media/usersImg.45bb36d4.svg"
  },
  {
    "revision": "b9ed454597f274af2e8b37ac99f1b4bc",
    "url": "./tables/media/widget-menu.b9ed4545.svg"
  }
]);