# Changelog

## [1.2.1]

- Update dependencies
- Add animation to alert in header
- Fix color in notifications
- Fix animated classes
- Fix color in chart dropdown menu

## [1.2.0]

Added Breadcrumbs component

## [1.1.1]

Fixed tables color

## [1.1.0]

Updated demo in the docs folder

## [1.0.0]

Initial release
